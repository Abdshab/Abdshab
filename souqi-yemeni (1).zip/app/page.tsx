import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"
import Image from "next/image"
import CategoryList from "@/components/home/category-list"
import FeaturedProducts from "@/components/home/featured-products"
import HeroSection from "@/components/home/hero-section"

export default function Home() {
  return (
    <div className="container mx-auto px-4 py-8">
      <HeroSection />

      <section className="my-12">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">الأقسام الرئيسية</h2>
          <Link href="/categories" className="text-primary hover:underline">
            عرض الكل
          </Link>
        </div>
        <CategoryList />
      </section>

      <section className="my-12">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">منتجات مميزة</h2>
          <Link href="/products" className="text-primary hover:underline">
            عرض الكل
          </Link>
        </div>
        <FeaturedProducts />
      </section>

      <section className="my-12 bg-muted rounded-lg p-6">
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold mb-2">مميزات سوقي اليمني</h2>
          <p className="text-muted-foreground">تجربة تسوق فريدة مصممة خصيصاً للسوق اليمني</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardContent className="p-6 text-center">
              <div className="mb-4 mx-auto w-16 h-16 flex items-center justify-center rounded-full bg-primary/10">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-primary w-8 h-8"
                >
                  <path d="M3 3v18h18" />
                  <path d="m19 9-5 5-4-4-3 3" />
                </svg>
              </div>
              <h3 className="font-bold mb-2">يعمل بدون إنترنت</h3>
              <p className="text-muted-foreground">تصفح المنتجات وإدارة متجرك حتى بدون اتصال بالإنترنت</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 text-center">
              <div className="mb-4 mx-auto w-16 h-16 flex items-center justify-center rounded-full bg-primary/10">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-primary w-8 h-8"
                >
                  <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
                </svg>
              </div>
              <h3 className="font-bold mb-2">تواصل مباشر</h3>
              <p className="text-muted-foreground">تواصل مباشرة مع البائعين عبر واتساب أو الاتصال</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 text-center">
              <div className="mb-4 mx-auto w-16 h-16 flex items-center justify-center rounded-full bg-primary/10">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-primary w-8 h-8"
                >
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
                </svg>
              </div>
              <h3 className="font-bold mb-2">تجربة آمنة</h3>
              <p className="text-muted-foreground">تخزين محلي للبيانات وحماية خصوصية المستخدمين</p>
            </CardContent>
          </Card>
        </div>
      </section>

      <section className="my-12">
        <Card className="overflow-hidden">
          <div className="md:flex">
            <div className="md:w-1/2 p-8 flex flex-col justify-center">
              <h2 className="text-2xl font-bold mb-4">هل أنت تاجر؟</h2>
              <p className="mb-6 text-muted-foreground">
                انضم إلى منصة سوقي اليمني وابدأ في بيع منتجاتك بسهولة وبدون تكاليف
              </p>
              <div className="space-x-4 space-x-reverse">
                <Button asChild>
                  <Link href="/auth/register?type=seller">سجل كتاجر</Link>
                </Button>
                <Button variant="outline" asChild>
                  <Link href="/seller/dashboard">معرفة المزيد</Link>
                </Button>
              </div>
            </div>
            <div className="md:w-1/2 bg-muted">
              <Image
                src="/placeholder.svg?height=400&width=600"
                alt="صورة للتجار"
                width={600}
                height={400}
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </Card>
      </section>
    </div>
  )
}
