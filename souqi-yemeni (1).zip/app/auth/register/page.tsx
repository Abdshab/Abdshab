"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useRouter, useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Mock data for cities and business types
const cities = [
  "صنعاء",
  "عدن",
  "تعز",
  "الحديدة",
  "إب",
  "ذمار",
  "المكلا",
  "سيئون",
  "عمران",
  "حجة",
  "البيضاء",
  "رداع",
  "لحج",
  "أبين",
  "مأرب",
  "شبوة",
  "الضالع",
  "المحويت",
  "صعدة",
  "الجوف",
]

const businessTypes = [
  "متجر إلكترونيات",
  "ملابس وأزياء",
  "مواد غذائية",
  "عسل ومنتجات طبيعية",
  "أدوات منزلية",
  "هدايا وإكسسوارات",
  "خدمات",
  "أخرى",
]

export default function RegisterPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const defaultTab = searchParams.get("type") === "seller" ? "seller" : "buyer"

  const [tab, setTab] = useState(defaultTab)
  const [name, setName] = useState("")
  const [phoneNumber, setPhoneNumber] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [city, setCity] = useState("")
  const [businessType, setBusinessType] = useState("")
  const [description, setDescription] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    // Basic validation
    if (password !== confirmPassword) {
      setError("كلمات المرور غير متطابقة")
      setLoading(false)
      return
    }

    try {
      // In a real app, this would be an API call
      // For demo purposes, we'll simulate a successful registration
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Mock user data
      const userData = {
        id: Math.floor(Math.random() * 1000),
        name,
        phoneNumber,
        isSeller: tab === "seller",
        city: tab === "seller" ? city : null,
        businessType: tab === "seller" ? businessType : null,
        description: tab === "seller" ? description : null,
      }

      // Store user data in localStorage
      localStorage.setItem("user", JSON.stringify(userData))

      // Redirect based on user type
      if (tab === "seller") {
        router.push("/seller/dashboard")
      } else {
        router.push("/")
      }
    } catch (err) {
      setError("حدث خطأ أثناء التسجيل. يرجى المحاولة مرة أخرى.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-md mx-auto">
        <Tabs value={tab} onValueChange={setTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="buyer">مشتري</TabsTrigger>
            <TabsTrigger value="seller">تاجر</TabsTrigger>
          </TabsList>

          <TabsContent value="buyer">
            <Card>
              <CardHeader>
                <CardTitle>تسجيل حساب جديد</CardTitle>
                <CardDescription>قم بإنشاء حساب جديد للتسوق على منصة سوقي اليمني</CardDescription>
              </CardHeader>
              <form onSubmit={handleRegister}>
                <CardContent className="space-y-4">
                  {error && <div className="bg-destructive/10 text-destructive p-3 rounded-md text-sm">{error}</div>}
                  <div className="space-y-2">
                    <Label htmlFor="name">الاسم الكامل</Label>
                    <Input
                      id="name"
                      placeholder="أدخل اسمك الكامل"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">رقم الهاتف</Label>
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="أدخل رقم هاتفك"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password">كلمة المرور</Label>
                    <Input
                      id="password"
                      type="password"
                      placeholder="أدخل كلمة المرور"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="confirmPassword">تأكيد كلمة المرور</Label>
                    <Input
                      id="confirmPassword"
                      type="password"
                      placeholder="أعد إدخال كلمة المرور"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      required
                    />
                  </div>
                </CardContent>
                <CardFooter className="flex flex-col space-y-4">
                  <Button type="submit" className="w-full" disabled={loading}>
                    {loading ? "جاري التسجيل..." : "تسجيل"}
                  </Button>
                  <div className="text-center text-sm">
                    لديك حساب بالفعل؟{" "}
                    <Link href="/auth/login" className="text-primary hover:underline">
                      تسجيل الدخول
                    </Link>
                  </div>
                </CardFooter>
              </form>
            </Card>
          </TabsContent>

          <TabsContent value="seller">
            <Card>
              <CardHeader>
                <CardTitle>تسجيل حساب تاجر</CardTitle>
                <CardDescription>قم بإنشاء حساب تاجر للبدء في بيع منتجاتك على منصة سوقي اليمني</CardDescription>
              </CardHeader>
              <form onSubmit={handleRegister}>
                <CardContent className="space-y-4">
                  {error && <div className="bg-destructive/10 text-destructive p-3 rounded-md text-sm">{error}</div>}
                  <div className="space-y-2">
                    <Label htmlFor="seller-name">اسم المتجر</Label>
                    <Input
                      id="seller-name"
                      placeholder="أدخل اسم متجرك"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="seller-phone">رقم الهاتف</Label>
                    <Input
                      id="seller-phone"
                      type="tel"
                      placeholder="أدخل رقم هاتفك"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="city">المدينة</Label>
                    <Select value={city} onValueChange={setCity} required>
                      <SelectTrigger>
                        <SelectValue placeholder="اختر المدينة" />
                      </SelectTrigger>
                      <SelectContent>
                        {cities.map((city) => (
                          <SelectItem key={city} value={city}>
                            {city}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="businessType">نوع النشاط التجاري</Label>
                    <Select value={businessType} onValueChange={setBusinessType} required>
                      <SelectTrigger>
                        <SelectValue placeholder="اختر نوع النشاط" />
                      </SelectTrigger>
                      <SelectContent>
                        {businessTypes.map((type) => (
                          <SelectItem key={type} value={type}>
                            {type}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="description">وصف مختصر لمتجرك</Label>
                    <Textarea
                      id="description"
                      placeholder="اكتب وصفاً مختصراً لمتجرك"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      rows={3}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="seller-password">كلمة المرور</Label>
                    <Input
                      id="seller-password"
                      type="password"
                      placeholder="أدخل كلمة المرور"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="seller-confirmPassword">تأكيد كلمة المرور</Label>
                    <Input
                      id="seller-confirmPassword"
                      type="password"
                      placeholder="أعد إدخال كلمة المرور"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      required
                    />
                  </div>
                </CardContent>
                <CardFooter className="flex flex-col space-y-4">
                  <Button type="submit" className="w-full" disabled={loading}>
                    {loading ? "جاري التسجيل..." : "تسجيل كتاجر"}
                  </Button>
                  <div className="text-center text-sm">
                    لديك حساب بالفعل؟{" "}
                    <Link href="/auth/login" className="text-primary hover:underline">
                      تسجيل الدخول
                    </Link>
                  </div>
                </CardFooter>
              </form>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
