"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function LoginPage() {
  const router = useRouter()
  const [phoneNumber, setPhoneNumber] = useState("")
  const [password, setPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    try {
      // In a real app, this would be an API call
      // For demo purposes, we'll simulate a successful login
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Mock user data
      const userData = {
        id: 1,
        name: "مستخدم تجريبي",
        phoneNumber,
        isSeller: phoneNumber === "777123456", // Just for demo
      }

      // Store user data in localStorage
      localStorage.setItem("user", JSON.stringify(userData))

      // Redirect based on user type
      if (userData.isSeller) {
        router.push("/seller/dashboard")
      } else {
        router.push("/")
      }
    } catch (err) {
      setError("حدث خطأ أثناء تسجيل الدخول. يرجى المحاولة مرة أخرى.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-md mx-auto">
        <Tabs defaultValue="phone" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="phone">رقم الهاتف</TabsTrigger>
            <TabsTrigger value="guest">تصفح كزائر</TabsTrigger>
          </TabsList>

          <TabsContent value="phone">
            <Card>
              <CardHeader>
                <CardTitle>تسجيل الدخول</CardTitle>
                <CardDescription>قم بتسجيل الدخول باستخدام رقم هاتفك وكلمة المرور</CardDescription>
              </CardHeader>
              <form onSubmit={handleLogin}>
                <CardContent className="space-y-4">
                  {error && <div className="bg-destructive/10 text-destructive p-3 rounded-md text-sm">{error}</div>}
                  <div className="space-y-2">
                    <Label htmlFor="phone">رقم الهاتف</Label>
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="أدخل رقم هاتفك"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="password">كلمة المرور</Label>
                      <Link href="/auth/forgot-password" className="text-sm text-primary hover:underline">
                        نسيت كلمة المرور؟
                      </Link>
                    </div>
                    <Input
                      id="password"
                      type="password"
                      placeholder="أدخل كلمة المرور"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                    />
                  </div>
                </CardContent>
                <CardFooter className="flex flex-col space-y-4">
                  <Button type="submit" className="w-full" disabled={loading}>
                    {loading ? "جاري تسجيل الدخول..." : "تسجيل الدخول"}
                  </Button>
                  <div className="text-center text-sm">
                    ليس لديك حساب؟{" "}
                    <Link href="/auth/register" className="text-primary hover:underline">
                      سجل الآن
                    </Link>
                  </div>
                </CardFooter>
              </form>
            </Card>
          </TabsContent>

          <TabsContent value="guest">
            <Card>
              <CardHeader>
                <CardTitle>تصفح كزائر</CardTitle>
                <CardDescription>يمكنك تصفح المنتجات بدون تسجيل الدخول</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-muted-foreground">
                  التصفح كزائر يتيح لك الوصول إلى جميع المنتجات والأقسام، لكن بعض الميزات قد تكون محدودة.
                </p>
              </CardContent>
              <CardFooter>
                <Button className="w-full" onClick={() => router.push("/products")}>
                  تصفح المنتجات
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
