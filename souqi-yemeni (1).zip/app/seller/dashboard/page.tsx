"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { BarChart, Package, ShoppingCart, Users, Plus, Upload, Download } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

// Mock data for products
const mockProducts = [
  {
    id: 1,
    title: "عسل سدر يمني أصلي",
    price: 15000,
    category: "عسل",
    quantity: 10,
    views: 120,
    status: "published",
    image: "/placeholder.svg?height=100&width=100",
  },
  {
    id: 2,
    title: "عسل طلح يمني",
    price: 12000,
    category: "عسل",
    quantity: 5,
    views: 85,
    status: "published",
    image: "/placeholder.svg?height=100&width=100",
  },
  {
    id: 3,
    title: "عسل سمر يمني",
    price: 10000,
    category: "عسل",
    quantity: 8,
    views: 65,
    status: "draft",
    image: "/placeholder.svg?height=100&width=100",
  },
]

// Mock data for categories
const categories = ["عسل", "ملابس", "إلكترونيات", "مواد غذائية", "أدوات منزلية", "هدايا", "أخرى"]

// Mock data for cities
const cities = ["صنعاء", "عدن", "تعز", "الحديدة", "إب", "ذمار", "المكلا", "سيئون"]

export default function SellerDashboard() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [products, setProducts] = useState(mockProducts)

  // Form states for adding new product
  const [productTitle, setProductTitle] = useState("")
  const [productPrice, setProductPrice] = useState("")
  const [productCategory, setProductCategory] = useState("")
  const [productQuantity, setProductQuantity] = useState("")
  const [productDescription, setProductDescription] = useState("")
  const [productCity, setProductCity] = useState("")
  const [productStatus, setProductStatus] = useState("published")
  const [productImages, setProductImages] = useState<string[]>([])

  useEffect(() => {
    // Check if user is logged in and is a seller
    const checkAuth = () => {
      const userData = localStorage.getItem("user")
      if (!userData) {
        router.push("/auth/login")
        return
      }

      const parsedUser = JSON.parse(userData)
      if (!parsedUser.isSeller) {
        router.push("/")
        return
      }

      setUser(parsedUser)
      setLoading(false)
    }

    checkAuth()
  }, [router])

  const handleAddProduct = (e: React.FormEvent) => {
    e.preventDefault()

    // Create new product
    const newProduct = {
      id: Date.now(),
      title: productTitle,
      price: Number(productPrice),
      category: productCategory,
      quantity: Number(productQuantity),
      views: 0,
      status: productStatus,
      image: "/placeholder.svg?height=100&width=100", // Default placeholder
    }

    // Add to products list
    setProducts([newProduct, ...products])

    // Reset form
    setProductTitle("")
    setProductPrice("")
    setProductCategory("")
    setProductQuantity("")
    setProductDescription("")
    setProductCity("")
    setProductStatus("published")
    setProductImages([])

    // Show success message or redirect
    alert("تم إضافة المنتج بنجاح")
  }

  const handleImageUpload = () => {
    // In a real app, this would handle file uploads
    // For demo, we'll just add a placeholder
    setProductImages([...productImages, "/placeholder.svg?height=100&width=100"])
  }

  const handleRemoveImage = (index: number) => {
    const newImages = [...productImages]
    newImages.splice(index, 1)
    setProductImages(newImages)
  }

  if (loading) {
    return <div className="container mx-auto px-4 py-12 text-center">جاري التحميل...</div>
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold">لوحة التحكم</h1>
          <p className="text-muted-foreground">مرحباً بك، {user?.name}</p>
        </div>
        <div className="mt-4 md:mt-0">
          <Button asChild>
            <Link href="/seller/dashboard/add-product">
              <Plus className="ml-2 h-4 w-4" /> إضافة منتج جديد
            </Link>
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">إجمالي المنتجات</p>
                <h3 className="text-2xl font-bold">{products.length}</h3>
              </div>
              <div className="p-2 bg-primary/10 rounded-full">
                <Package className="h-6 w-6 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">إجمالي المشاهدات</p>
                <h3 className="text-2xl font-bold">{products.reduce((sum, product) => sum + product.views, 0)}</h3>
              </div>
              <div className="p-2 bg-primary/10 rounded-full">
                <BarChart className="h-6 w-6 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">الطلبات</p>
                <h3 className="text-2xl font-bold">0</h3>
              </div>
              <div className="p-2 bg-primary/10 rounded-full">
                <ShoppingCart className="h-6 w-6 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">الزوار</p>
                <h3 className="text-2xl font-bold">0</h3>
              </div>
              <div className="p-2 bg-primary/10 rounded-full">
                <Users className="h-6 w-6 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="products" className="w-full">
        <TabsList className="mb-6">
          <TabsTrigger value="products">المنتجات</TabsTrigger>
          <TabsTrigger value="add-product">إضافة منتج</TabsTrigger>
          <TabsTrigger value="import-export">استيراد / تصدير</TabsTrigger>
        </TabsList>

        <TabsContent value="products">
          <Card>
            <CardHeader>
              <CardTitle>إدارة المنتجات</CardTitle>
              <CardDescription>عرض وتعديل وحذف المنتجات الخاصة بك</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b">
                      <th className="text-right py-3 px-4">المنتج</th>
                      <th className="text-right py-3 px-4">السعر</th>
                      <th className="text-right py-3 px-4">الكمية</th>
                      <th className="text-right py-3 px-4">المشاهدات</th>
                      <th className="text-right py-3 px-4">الحالة</th>
                      <th className="text-right py-3 px-4">الإجراءات</th>
                    </tr>
                  </thead>
                  <tbody>
                    {products.map((product) => (
                      <tr key={product.id} className="border-b">
                        <td className="py-3 px-4">
                          <div className="flex items-center">
                            <Image
                              src={product.image || "/placeholder.svg"}
                              alt={product.title}
                              width={40}
                              height={40}
                              className="rounded-md ml-2"
                            />
                            <span>{product.title}</span>
                          </div>
                        </td>
                        <td className="py-3 px-4">{product.price.toLocaleString("ar-YE")} ر.ي</td>
                        <td className="py-3 px-4">{product.quantity}</td>
                        <td className="py-3 px-4">{product.views}</td>
                        <td className="py-3 px-4">
                          <span
                            className={`px-2 py-1 rounded-full text-xs ${
                              product.status === "published"
                                ? "bg-green-100 text-green-800"
                                : "bg-yellow-100 text-yellow-800"
                            }`}
                          >
                            {product.status === "published" ? "منشور" : "مسودة"}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex space-x-2 space-x-reverse">
                            <Button variant="outline" size="sm">
                              تعديل
                            </Button>
                            <Button variant="destructive" size="sm">
                              حذف
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="add-product">
          <Card>
            <CardHeader>
              <CardTitle>إضافة منتج جديد</CardTitle>
              <CardDescription>أضف منتجاً جديداً إلى متجرك</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleAddProduct} className="space-y-6">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="product-title">عنوان المنتج</Label>
                    <Input
                      id="product-title"
                      placeholder="أدخل عنوان المنتج"
                      value={productTitle}
                      onChange={(e) => setProductTitle(e.target.value)}
                      required
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="product-price">السعر (ر.ي)</Label>
                      <Input
                        id="product-price"
                        type="number"
                        placeholder="أدخل سعر المنتج"
                        value={productPrice}
                        onChange={(e) => setProductPrice(e.target.value)}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="product-quantity">الكمية</Label>
                      <Input
                        id="product-quantity"
                        type="number"
                        placeholder="أدخل الكمية المتوفرة"
                        value={productQuantity}
                        onChange={(e) => setProductQuantity(e.target.value)}
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="product-category">القسم</Label>
                      <Select value={productCategory} onValueChange={setProductCategory} required>
                        <SelectTrigger id="product-category">
                          <SelectValue placeholder="اختر القسم" />
                        </SelectTrigger>
                        <SelectContent>
                          {categories.map((category) => (
                            <SelectItem key={category} value={category}>
                              {category}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="product-city">المدينة</Label>
                      <Select value={productCity} onValueChange={setProductCity} required>
                        <SelectTrigger id="product-city">
                          <SelectValue placeholder="اختر المدينة" />
                        </SelectTrigger>
                        <SelectContent>
                          {cities.map((city) => (
                            <SelectItem key={city} value={city}>
                              {city}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="product-description">وصف المنتج</Label>
                    <Textarea
                      id="product-description"
                      placeholder="اكتب وصفاً تفصيلياً للمنتج"
                      value={productDescription}
                      onChange={(e) => setProductDescription(e.target.value)}
                      rows={5}
                      required
                    />
                  </div>

                  <div>
                    <Label>صور المنتج</Label>
                    <div className="mt-2 border-2 border-dashed rounded-lg p-6 text-center">
                      <Button type="button" variant="outline" onClick={handleImageUpload}>
                        <Upload className="ml-2 h-4 w-4" /> رفع صور
                      </Button>
                      <p className="mt-2 text-sm text-muted-foreground">
                        يمكنك رفع حتى 5 صور للمنتج. الصيغ المدعومة: JPG، PNG، WEBP
                      </p>

                      {productImages.length > 0 && (
                        <div className="mt-4 grid grid-cols-5 gap-4">
                          {productImages.map((image, index) => (
                            <div key={index} className="relative">
                              <Image
                                src={image || "/placeholder.svg"}
                                alt={`صورة ${index + 1}`}
                                width={100}
                                height={100}
                                className="rounded-md"
                              />
                              <Button
                                type="button"
                                variant="destructive"
                                size="icon"
                                className="absolute top-0 left-0 h-6 w-6"
                                onClick={() => handleRemoveImage(index)}
                              >
                                &times;
                              </Button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="product-status">حالة المنتج</Label>
                    <Select value={productStatus} onValueChange={setProductStatus}>
                      <SelectTrigger id="product-status">
                        <SelectValue placeholder="اختر حالة المنتج" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="published">منشور</SelectItem>
                        <SelectItem value="draft">مسودة</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="flex justify-end space-x-4 space-x-reverse">
                  <Button type="button" variant="outline">
                    إلغاء
                  </Button>
                  <Button type="submit">إضافة المنتج</Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="import-export">
          <Card>
            <CardHeader>
              <CardTitle>استيراد وتصدير المنتجات</CardTitle>
              <CardDescription>استيراد المنتجات من ملف CSV أو تصدير المنتجات الحالية</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="border rounded-lg p-6">
                <h3 className="text-lg font-medium mb-4">تصدير المنتجات</h3>
                <p className="text-muted-foreground mb-4">
                  قم بتصدير جميع منتجاتك إلى ملف CSV يمكنك تعديله وإعادة استيراده لاحقاً.
                </p>
                <Button>
                  <Download className="ml-2 h-4 w-4" /> تصدير إلى CSV
                </Button>
              </div>

              <div className="border rounded-lg p-6">
                <h3 className="text-lg font-medium mb-4">استيراد المنتجات</h3>
                <p className="text-muted-foreground mb-4">
                  قم باستيراد منتجات من ملف CSV. تأكد من اتباع التنسيق الصحيح للملف.
                </p>
                <div className="space-y-4">
                  <div className="border-2 border-dashed rounded-lg p-6 text-center">
                    <Button variant="outline">
                      <Upload className="ml-2 h-4 w-4" /> اختر ملف CSV
                    </Button>
                    <p className="mt-2 text-sm text-muted-foreground">أو قم بسحب وإفلات الملف هنا</p>
                  </div>
                  <Button disabled>استيراد المنتجات</Button>
                  <div>
                    <p className="text-sm text-muted-foreground">
                      <a href="#" className="text-primary hover:underline">
                        تنزيل نموذج CSV
                      </a>{" "}
                      لمعرفة التنسيق الصحيح.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
