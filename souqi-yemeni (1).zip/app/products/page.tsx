"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Heart, MessageCircle, Search, SlidersHorizontal } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

// Mock data for products
const mockProducts = [
  {
    id: 1,
    title: "عسل سدر يمني أصلي",
    price: 15000,
    location: "صنعاء",
    image: "/placeholder.svg?height=200&width=300",
    seller: "متجر العسل اليمني",
    category: "عسل",
  },
  {
    id: 2,
    title: "جوال سامسونج جالكسي A54",
    price: 180000,
    location: "عدن",
    image: "/placeholder.svg?height=200&width=300",
    seller: "متجر التقنية",
    category: "إلكترونيات",
  },
  {
    id: 3,
    title: "ثوب يمني تقليدي",
    price: 12000,
    location: "تعز",
    image: "/placeholder.svg?height=200&width=300",
    seller: "بيت الأزياء",
    category: "ملابس",
  },
  {
    id: 4,
    title: "جنبية يمنية تقليدية",
    price: 25000,
    location: "صنعاء",
    image: "/placeholder.svg?height=200&width=300",
    seller: "متجر التراث",
    category: "هدايا",
  },
  {
    id: 5,
    title: "بن يمني فاخر",
    price: 8000,
    location: "إب",
    image: "/placeholder.svg?height=200&width=300",
    seller: "متجر البن اليمني",
    category: "مواد غذائية",
  },
  {
    id: 6,
    title: "سلة هدايا يمنية",
    price: 20000,
    location: "صنعاء",
    image: "/placeholder.svg?height=200&width=300",
    seller: "متجر الهدايا",
    category: "هدايا",
  },
  {
    id: 7,
    title: "عسل طلح يمني",
    price: 12000,
    location: "ذمار",
    image: "/placeholder.svg?height=200&width=300",
    seller: "متجر العسل اليمني",
    category: "عسل",
  },
  {
    id: 8,
    title: "سماعات بلوتوث",
    price: 15000,
    location: "عدن",
    image: "/placeholder.svg?height=200&width=300",
    seller: "متجر التقنية",
    category: "إلكترونيات",
  },
]

// Mock data for categories
const categories = ["الكل", "عسل", "ملابس", "إلكترونيات", "مواد غذائية", "أدوات منزلية", "هدايا", "أخرى"]

// Mock data for cities
const cities = ["الكل", "صنعاء", "عدن", "تعز", "الحديدة", "إب", "ذمار", "المكلا", "سيئون"]

export default function ProductsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("الكل")
  const [selectedCity, setSelectedCity] = useState("الكل")
  const [priceRange, setPriceRange] = useState([0, 200000])
  const [showFilters, setShowFilters] = useState(false)
  const [favorites, setFavorites] = useState<number[]>([])
  const [sortBy, setSortBy] = useState("newest")

  // Filter products based on search query, category, city, and price range
  const filteredProducts = mockProducts.filter((product) => {
    const matchesSearch = product.title.includes(searchQuery) || product.seller.includes(searchQuery)
    const matchesCategory = selectedCategory === "الكل" || product.category === selectedCategory
    const matchesCity = selectedCity === "الكل" || product.location === selectedCity
    const matchesPrice = product.price >= priceRange[0] && product.price <= priceRange[1]

    return matchesSearch && matchesCategory && matchesCity && matchesPrice
  })

  // Sort products
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    if (sortBy === "price-asc") {
      return a.price - b.price
    } else if (sortBy === "price-desc") {
      return b.price - a.price
    } else {
      // Default: newest
      return b.id - a.id
    }
  })

  const toggleFavorite = (productId: number) => {
    setFavorites((prev) => {
      if (prev.includes(productId)) {
        return prev.filter((id) => id !== productId)
      } else {
        return [...prev, productId]
      }
    })
  }

  const formatPrice = (price: number) => {
    return price.toLocaleString("ar-YE") + " ر.ي"
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">تصفح المنتجات</h1>

      <div className="mb-6">
        <div className="relative">
          <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-5 w-5" />
          <Input
            type="search"
            placeholder="ابحث عن منتجات..."
            className="pr-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      <div className="flex flex-wrap gap-2 mb-6">
        {categories.map((category) => (
          <Badge
            key={category}
            variant={selectedCategory === category ? "default" : "outline"}
            className="cursor-pointer"
            onClick={() => setSelectedCategory(category)}
          >
            {category}
          </Badge>
        ))}
      </div>

      <div className="flex justify-between items-center mb-6">
        <Button variant="outline" onClick={() => setShowFilters(!showFilters)} className="flex items-center gap-2">
          <SlidersHorizontal className="h-4 w-4" />
          <span>الفلاتر</span>
        </Button>

        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">ترتيب حسب:</span>
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="الأحدث" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">الأحدث</SelectItem>
              <SelectItem value="price-asc">السعر: من الأقل للأعلى</SelectItem>
              <SelectItem value="price-desc">السعر: من الأعلى للأقل</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {showFilters && (
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <Label className="mb-2 block">المدينة</Label>
                <Select value={selectedCity} onValueChange={setSelectedCity}>
                  <SelectTrigger>
                    <SelectValue placeholder="اختر المدينة" />
                  </SelectTrigger>
                  <SelectContent>
                    {cities.map((city) => (
                      <SelectItem key={city} value={city}>
                        {city}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="mb-2 block">نطاق السعر</Label>
                <div className="pt-4">
                  <Slider value={priceRange} min={0} max={200000} step={1000} onValueChange={setPriceRange} />
                  <div className="flex justify-between mt-2 text-sm">
                    <span>{formatPrice(priceRange[0])}</span>
                    <span>{formatPrice(priceRange[1])}</span>
                  </div>
                </div>
              </div>

              <div>
                <Label className="mb-2 block">خيارات إضافية</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <Checkbox id="new-only" />
                    <Label htmlFor="new-only" className="text-sm">
                      منتجات جديدة فقط
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <Checkbox id="with-images" />
                    <Label htmlFor="with-images" className="text-sm">
                      منتجات بصور فقط
                    </Label>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {sortedProducts.map((product) => (
          <Card key={product.id} className="overflow-hidden">
            <div className="relative">
              <Link href={`/products/${product.id}`}>
                <Image
                  src={product.image || "/placeholder.svg"}
                  alt={product.title}
                  width={300}
                  height={200}
                  className="w-full h-48 object-cover"
                />
              </Link>
              <Button
                variant="ghost"
                size="icon"
                className="absolute top-2 left-2 bg-white/80 hover:bg-white/90 rounded-full"
                onClick={() => toggleFavorite(product.id)}
              >
                <Heart className={`h-5 w-5 ${favorites.includes(product.id) ? "fill-red-500 text-red-500" : ""}`} />
              </Button>
              <Badge className="absolute top-2 right-2">{product.category}</Badge>
            </div>
            <CardContent className="p-4">
              <Link href={`/products/${product.id}`} className="hover:underline">
                <h3 className="font-bold text-lg mb-2 line-clamp-1">{product.title}</h3>
              </Link>
              <div className="flex justify-between items-center mb-2">
                <span className="font-bold text-primary">{formatPrice(product.price)}</span>
                <span className="text-sm text-muted-foreground">{product.location}</span>
              </div>
              <p className="text-sm text-muted-foreground">{product.seller}</p>

              <div className="mt-4 flex justify-between">
                <Button variant="outline" size="sm" asChild>
                  <Link href={`/products/${product.id}`}>التفاصيل</Link>
                </Button>
                <Button variant="secondary" size="sm" className="flex items-center gap-1">
                  <MessageCircle className="h-4 w-4" />
                  <span>تواصل</span>
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {sortedProducts.length === 0 && (
        <div className="text-center py-12">
          <p className="text-xl text-muted-foreground">لا توجد منتجات تطابق معايير البحث</p>
          <Button
            variant="link"
            onClick={() => {
              setSearchQuery("")
              setSelectedCategory("الكل")
              setSelectedCity("الكل")
              setPriceRange([0, 200000])
            }}
          >
            إعادة ضبط الفلاتر
          </Button>
        </div>
      )}
    </div>
  )
}
