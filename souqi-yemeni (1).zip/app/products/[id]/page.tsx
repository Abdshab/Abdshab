"use client"

import { useState, useEffect } from "react"
import { useParams } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Heart, MessageCircle, Phone, Share2, ShoppingCart } from "lucide-react"

// Mock data for product details
const mockProducts = [
  {
    id: "1",
    title: "عسل سدر يمني أصلي",
    price: 15000,
    location: "صنعاء",
    images: [
      "/placeholder.svg?height=400&width=600",
      "/placeholder.svg?height=400&width=600",
      "/placeholder.svg?height=400&width=600",
    ],
    seller: {
      name: "متجر العسل اليمني",
      phone: "777123456",
      whatsapp: "777123456",
    },
    category: "عسل",
    description:
      "عسل سدر يمني أصلي 100% من جبال اليمن. يتميز بلونه الذهبي ومذاقه الفريد. مناسب للاستخدام اليومي ويحتوي على فوائد صحية عديدة. العبوة: 1 كيلو جرام.",
    specifications: [
      { name: "النوع", value: "سدر" },
      { name: "الوزن", value: "1 كيلو جرام" },
      { name: "بلد المنشأ", value: "اليمن" },
      { name: "تاريخ الإنتاج", value: "2023" },
    ],
    relatedProducts: [2, 7],
  },
  {
    id: "2",
    title: "جوال سامسونج جالكسي A54",
    price: 180000,
    location: "عدن",
    images: ["/placeholder.svg?height=400&width=600", "/placeholder.svg?height=400&width=600"],
    seller: {
      name: "متجر التقنية",
      phone: "777654321",
      whatsapp: "777654321",
    },
    category: "إلكترونيات",
    description:
      "هاتف سامسونج جالكسي A54 بذاكرة 128 جيجابايت وذاكرة وصول عشوائي 8 جيجابايت. شاشة سوبر أموليد 6.4 بوصة، كاميرا خلفية ثلاثية 50 ميجابكسل، بطارية 5000 مللي أمبير.",
    specifications: [
      { name: "الذاكرة", value: "128 جيجابايت" },
      { name: "ذاكرة الوصول العشوائي", value: "8 جيجابايت" },
      { name: "الشاشة", value: "6.4 بوصة سوبر أموليد" },
      { name: "البطارية", value: "5000 مللي أمبير" },
      { name: "الكاميرا الخلفية", value: "ثلاثية 50 ميجابكسل" },
      { name: "نظام التشغيل", value: "أندرويد 13" },
    ],
    relatedProducts: [8],
  },
]

// Mock data for related products
const relatedProductsData = [
  {
    id: 2,
    title: "عسل طلح يمني",
    price: 12000,
    image: "/placeholder.svg?height=200&width=300",
    category: "عسل",
  },
  {
    id: 7,
    title: "عسل سمر يمني",
    price: 10000,
    image: "/placeholder.svg?height=200&width=300",
    category: "عسل",
  },
  {
    id: 8,
    title: "سماعات بلوتوث",
    price: 15000,
    image: "/placeholder.svg?height=200&width=300",
    category: "إلكترونيات",
  },
]

export default function ProductDetailPage() {
  const params = useParams()
  const productId = params.id as string

  const [product, setProduct] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [selectedImage, setSelectedImage] = useState(0)
  const [isFavorite, setIsFavorite] = useState(false)
  const [relatedProducts, setRelatedProducts] = useState<any[]>([])

  useEffect(() => {
    // Fetch product data
    const fetchProduct = () => {
      setLoading(true)
      // In a real app, this would be an API call
      const foundProduct = mockProducts.find((p) => p.id === productId)

      if (foundProduct) {
        setProduct(foundProduct)

        // Get related products
        const related = relatedProductsData.filter((p) => foundProduct.relatedProducts.includes(p.id))
        setRelatedProducts(related)

        // Check if product is in favorites
        const favorites = JSON.parse(localStorage.getItem("favorites") || "[]")
        setIsFavorite(favorites.includes(Number(productId)))
      }

      setLoading(false)
    }

    fetchProduct()
  }, [productId])

  const toggleFavorite = () => {
    const favorites = JSON.parse(localStorage.getItem("favorites") || "[]")
    const productIdNum = Number(productId)

    if (isFavorite) {
      const newFavorites = favorites.filter((id: number) => id !== productIdNum)
      localStorage.setItem("favorites", JSON.stringify(newFavorites))
    } else {
      favorites.push(productIdNum)
      localStorage.setItem("favorites", JSON.stringify(favorites))
    }

    setIsFavorite(!isFavorite)
  }

  const formatPrice = (price: number) => {
    return price.toLocaleString("ar-YE") + " ر.ي"
  }

  if (loading) {
    return <div className="container mx-auto px-4 py-12 text-center">جاري التحميل...</div>
  }

  if (!product) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h1 className="text-2xl font-bold mb-4">المنتج غير موجود</h1>
        <p className="mb-6">عذراً، لم يتم العثور على المنتج المطلوب.</p>
        <Button asChild>
          <Link href="/products">العودة إلى المنتجات</Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <Link href="/products" className="text-primary hover:underline">
          &larr; العودة إلى المنتجات
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
        {/* Product Images */}
        <div className="space-y-4">
          <div className="relative aspect-video overflow-hidden rounded-lg border">
            <Image
              src={product.images[selectedImage] || "/placeholder.svg"}
              alt={product.title}
              fill
              className="object-contain"
            />
          </div>

          <div className="flex space-x-2 space-x-reverse overflow-auto pb-2">
            {product.images.map((image: string, index: number) => (
              <div
                key={index}
                className={`relative h-20 w-20 flex-shrink-0 cursor-pointer rounded-md border-2 overflow-hidden ${
                  selectedImage === index ? "border-primary" : "border-transparent"
                }`}
                onClick={() => setSelectedImage(index)}
              >
                <Image
                  src={image || "/placeholder.svg"}
                  alt={`${product.title} - صورة ${index + 1}`}
                  fill
                  className="object-cover"
                />
              </div>
            ))}
          </div>
        </div>

        {/* Product Info */}
        <div>
          <div className="mb-6">
            <div className="flex items-center justify-between mb-2">
              <Badge>{product.category}</Badge>
              <div className="flex space-x-2 space-x-reverse">
                <Button variant="ghost" size="icon" onClick={toggleFavorite}>
                  <Heart className={`h-5 w-5 ${isFavorite ? "fill-red-500 text-red-500" : ""}`} />
                </Button>
                <Button variant="ghost" size="icon">
                  <Share2 className="h-5 w-5" />
                </Button>
              </div>
            </div>

            <h1 className="text-3xl font-bold mb-2">{product.title}</h1>

            <div className="flex items-center justify-between mb-4">
              <span className="text-2xl font-bold text-primary">{formatPrice(product.price)}</span>
              <span className="text-muted-foreground">{product.location}</span>
            </div>
          </div>

          <Tabs defaultValue="description" className="mb-6">
            <TabsList className="w-full">
              <TabsTrigger value="description" className="flex-1">
                الوصف
              </TabsTrigger>
              <TabsTrigger value="specifications" className="flex-1">
                المواصفات
              </TabsTrigger>
              <TabsTrigger value="seller" className="flex-1">
                البائع
              </TabsTrigger>
            </TabsList>

            <TabsContent value="description" className="mt-4">
              <p className="text-muted-foreground leading-relaxed">{product.description}</p>
            </TabsContent>

            <TabsContent value="specifications" className="mt-4">
              <div className="space-y-2">
                {product.specifications.map((spec: any, index: number) => (
                  <div key={index} className="flex justify-between py-2 border-b">
                    <span className="font-medium">{spec.name}</span>
                    <span className="text-muted-foreground">{spec.value}</span>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="seller" className="mt-4">
              <div className="space-y-4">
                <div className="flex items-center space-x-4 space-x-reverse">
                  <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                    <span className="text-primary font-bold">{product.seller.name.charAt(0)}</span>
                  </div>
                  <div>
                    <h3 className="font-bold">{product.seller.name}</h3>
                    <p className="text-sm text-muted-foreground">{product.location}</p>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <Button className="w-full" asChild>
                <a href={`https://wa.me/${product.seller.whatsapp}`} target="_blank" rel="noopener noreferrer">
                  <MessageCircle className="ml-2 h-5 w-5" />
                  تواصل عبر واتساب
                </a>
              </Button>
              <Button variant="outline" className="w-full" asChild>
                <a href={`tel:${product.seller.phone}`}>
                  <Phone className="ml-2 h-5 w-5" />
                  اتصل بالبائع
                </a>
              </Button>
            </div>

            <Button className="w-full" variant="secondary">
              <ShoppingCart className="ml-2 h-5 w-5" />
              أضف إلى السلة
            </Button>
          </div>
        </div>
      </div>

      {/* Related Products */}
      {relatedProducts.length > 0 && (
        <div className="mt-12">
          <h2 className="text-2xl font-bold mb-6">منتجات ذات صلة</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {relatedProducts.map((relatedProduct) => (
              <Card key={relatedProduct.id} className="overflow-hidden">
                <Link href={`/products/${relatedProduct.id}`}>
                  <div className="relative h-48">
                    <Image
                      src={relatedProduct.image || "/placeholder.svg"}
                      alt={relatedProduct.title}
                      fill
                      className="object-cover"
                    />
                    <Badge className="absolute top-2 right-2">{relatedProduct.category}</Badge>
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-bold text-lg mb-2 line-clamp-1">{relatedProduct.title}</h3>
                    <span className="font-bold text-primary">{formatPrice(relatedProduct.price)}</span>
                  </CardContent>
                </Link>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
