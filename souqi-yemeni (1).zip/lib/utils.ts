import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Function to check if we're in a browser environment
export function isBrowser() {
  return typeof window !== "undefined"
}

// Function to save data to localStorage
export function saveToLocalStorage(key: string, data: any) {
  if (isBrowser()) {
    try {
      localStorage.setItem(key, JSON.stringify(data))
      return true
    } catch (error) {
      console.error("Error saving to localStorage:", error)
      return false
    }
  }
  return false
}

// Function to get data from localStorage
export function getFromLocalStorage(key: string, defaultValue: any = null) {
  if (isBrowser()) {
    try {
      const item = localStorage.getItem(key)
      return item ? JSON.parse(item) : defaultValue
    } catch (error) {
      console.error("Error getting from localStorage:", error)
      return defaultValue
    }
  }
  return defaultValue
}

// Function to remove data from localStorage
export function removeFromLocalStorage(key: string) {
  if (isBrowser()) {
    try {
      localStorage.removeItem(key)
      return true
    } catch (error) {
      console.error("Error removing from localStorage:", error)
      return false
    }
  }
  return false
}

// Format price in Yemeni Rial
export function formatPrice(price: number) {
  return price.toLocaleString("ar-YE") + " ر.ي"
}
