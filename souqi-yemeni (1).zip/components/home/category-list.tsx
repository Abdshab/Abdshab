import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { ShoppingBag, Smartphone, Coffee, Utensils, Home, Gift, Shirt } from "lucide-react"

const categories = [
  {
    id: 1,
    name: "ملابس",
    icon: Shirt,
    slug: "clothing",
  },
  {
    id: 2,
    name: "إلكترونيات",
    icon: Smartphone,
    slug: "electronics",
  },
  {
    id: 3,
    name: "عسل",
    icon: Coffee,
    slug: "honey",
  },
  {
    id: 4,
    name: "مواد غذائية",
    icon: Utensils,
    slug: "food",
  },
  {
    id: 5,
    name: "أدوات منزلية",
    icon: Home,
    slug: "home",
  },
  {
    id: 6,
    name: "هدايا",
    icon: Gift,
    slug: "gifts",
  },
  {
    id: 7,
    name: "أخرى",
    icon: ShoppingBag,
    slug: "other",
  },
]

export default function CategoryList() {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-4">
      {categories.map((category) => (
        <Link key={category.id} href={`/categories/${category.slug}`}>
          <Card className="hover:border-primary transition-colors">
            <CardContent className="p-4 flex flex-col items-center justify-center text-center">
              <category.icon className="h-8 w-8 mb-2 text-primary" />
              <span>{category.name}</span>
            </CardContent>
          </Card>
        </Link>
      ))}
    </div>
  )
}
