import { Button } from "@/components/ui/button"
import Link from "next/link"
import Image from "next/image"

export default function HeroSection() {
  return (
    <section className="relative overflow-hidden rounded-lg bg-muted">
      <div className="container mx-auto px-4 py-16 md:py-24">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="text-center md:text-right">
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4">سوقي اليمني</h1>
            <p className="text-xl mb-6 text-muted-foreground">
              منصة التجارة الإلكترونية المصممة خصيصاً للسوق اليمني والعربي
            </p>
            <div className="flex flex-wrap gap-4 justify-center md:justify-start">
              <Button size="lg" asChild>
                <Link href="/products">تصفح المنتجات</Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link href="/auth/register?type=seller">سجل كتاجر</Link>
              </Button>
            </div>
          </div>
          <div className="relative h-64 md:h-auto">
            <Image
              src="/placeholder.svg?height=400&width=600"
              alt="سوقي اليمني"
              width={600}
              height={400}
              className="rounded-lg object-cover"
              priority
            />
          </div>
        </div>
      </div>
    </section>
  )
}
