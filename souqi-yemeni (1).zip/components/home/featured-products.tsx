"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Heart, MessageCircle } from "lucide-react"

// Mock data for featured products
const mockProducts = [
  {
    id: 1,
    title: "عسل سدر يمني أصلي",
    price: 15000,
    location: "صنعاء",
    image: "/placeholder.svg?height=200&width=300",
    seller: "متجر العسل اليمني",
    category: "عسل",
  },
  {
    id: 2,
    title: "جوال سامسونج جالكسي A54",
    price: 180000,
    location: "عدن",
    image: "/placeholder.svg?height=200&width=300",
    seller: "متجر التقنية",
    category: "إلكترونيات",
  },
  {
    id: 3,
    title: "ثوب يمني تقليدي",
    price: 12000,
    location: "تعز",
    image: "/placeholder.svg?height=200&width=300",
    seller: "بيت الأزياء",
    category: "ملابس",
  },
  {
    id: 4,
    title: "جنبية يمنية تقليدية",
    price: 25000,
    location: "صنعاء",
    image: "/placeholder.svg?height=200&width=300",
    seller: "متجر التراث",
    category: "هدايا",
  },
]

export default function FeaturedProducts() {
  const [products, setProducts] = useState(mockProducts)
  const [favorites, setFavorites] = useState<number[]>([])

  // Load favorites from localStorage on component mount
  useEffect(() => {
    if (typeof window !== "undefined") {
      const storedFavorites = localStorage.getItem("favorites")
      if (storedFavorites) {
        setFavorites(JSON.parse(storedFavorites))
      }
    }
  }, [])

  // Save favorites to localStorage when they change
  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem("favorites", JSON.stringify(favorites))
    }
  }, [favorites])

  const toggleFavorite = (productId: number) => {
    setFavorites((prev) => {
      if (prev.includes(productId)) {
        return prev.filter((id) => id !== productId)
      } else {
        return [...prev, productId]
      }
    })
  }

  const formatPrice = (price: number) => {
    return price.toLocaleString("ar-YE") + " ر.ي"
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
      {products.map((product) => (
        <Card key={product.id} className="overflow-hidden">
          <div className="relative">
            <Link href={`/products/${product.id}`}>
              <Image
                src={product.image || "/placeholder.svg"}
                alt={product.title}
                width={300}
                height={200}
                className="w-full h-48 object-cover"
              />
            </Link>
            <Button
              variant="ghost"
              size="icon"
              className="absolute top-2 left-2 bg-white/80 hover:bg-white/90 rounded-full"
              onClick={() => toggleFavorite(product.id)}
            >
              <Heart className={`h-5 w-5 ${favorites.includes(product.id) ? "fill-red-500 text-red-500" : ""}`} />
            </Button>
            <Badge className="absolute top-2 right-2">{product.category}</Badge>
          </div>
          <CardContent className="p-4">
            <Link href={`/products/${product.id}`} className="hover:underline">
              <h3 className="font-bold text-lg mb-2 line-clamp-1">{product.title}</h3>
            </Link>
            <div className="flex justify-between items-center mb-2">
              <span className="font-bold text-primary">{formatPrice(product.price)}</span>
              <span className="text-sm text-muted-foreground">{product.location}</span>
            </div>
            <p className="text-sm text-muted-foreground">{product.seller}</p>
          </CardContent>
          <CardFooter className="p-4 pt-0 flex justify-between">
            <Button variant="outline" size="sm" asChild>
              <Link href={`/products/${product.id}`}>التفاصيل</Link>
            </Button>
            <Button variant="secondary" size="sm" className="flex items-center gap-1">
              <MessageCircle className="h-4 w-4" />
              <span>تواصل</span>
            </Button>
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}
