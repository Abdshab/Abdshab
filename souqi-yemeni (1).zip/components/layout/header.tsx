"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { ModeToggle } from "@/components/mode-toggle"
import { useMobile } from "@/hooks/use-mobile"
import { Menu, Search, ShoppingCart, User } from "lucide-react"

export default function Header() {
  const isMobile = useMobile()
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [isSeller, setIsSeller] = useState(false)

  // Check if user is logged in from localStorage when component mounts
  useEffect(() => {
    if (typeof window !== "undefined") {
      const user = localStorage.getItem("user")
      if (user) {
        setIsLoggedIn(true)
        const userData = JSON.parse(user)
        setIsSeller(userData.isSeller || false)
      }
    }
  }, [])

  return (
    <header className="border-b sticky top-0 z-50 bg-background">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link href="/" className="font-bold text-xl text-primary">
            سوقي اليمني
          </Link>

          {/* Search Bar - Hidden on Mobile */}
          {!isMobile && (
            <div className="w-1/3 mx-4">
              <div className="relative">
                <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input type="search" placeholder="ابحث عن منتجات..." className="w-full pr-10" />
              </div>
            </div>
          )}

          {/* Desktop Navigation */}
          {!isMobile && (
            <nav className="flex items-center space-x-4 space-x-reverse">
              <Link href="/products" className="text-sm hover:text-primary">
                المنتجات
              </Link>
              <Link href="/categories" className="text-sm hover:text-primary">
                الأقسام
              </Link>
              <Link href="/about" className="text-sm hover:text-primary">
                عن المنصة
              </Link>
              <Link href="/contact" className="text-sm hover:text-primary">
                اتصل بنا
              </Link>
            </nav>
          )}

          {/* Actions */}
          <div className="flex items-center space-x-3 space-x-reverse">
            {/* Search Icon - Mobile Only */}
            {isMobile && (
              <Button variant="ghost" size="icon" aria-label="بحث">
                <Search className="h-5 w-5" />
              </Button>
            )}

            {/* Cart */}
            <Button variant="ghost" size="icon" aria-label="سلة التسوق">
              <ShoppingCart className="h-5 w-5" />
            </Button>

            {/* User Menu */}
            {isLoggedIn ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" aria-label="حسابي">
                    <User className="h-5 w-5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem asChild>
                    <Link href="/profile">الملف الشخصي</Link>
                  </DropdownMenuItem>
                  {isSeller && (
                    <DropdownMenuItem asChild>
                      <Link href="/seller/dashboard">لوحة التحكم</Link>
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuItem asChild>
                    <Link href="/orders">طلباتي</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/favorites">المفضلة</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onClick={() => {
                      localStorage.removeItem("user")
                      setIsLoggedIn(false)
                    }}
                  >
                    تسجيل الخروج
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <div className="flex items-center space-x-2 space-x-reverse">
                <Button variant="outline" size="sm" asChild>
                  <Link href="/auth/login">تسجيل الدخول</Link>
                </Button>
                <Button size="sm" asChild>
                  <Link href="/auth/register">التسجيل</Link>
                </Button>
              </div>
            )}

            {/* Theme Toggle */}
            <ModeToggle />

            {/* Mobile Menu */}
            {isMobile && (
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" aria-label="القائمة">
                    <Menu className="h-5 w-5" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right">
                  <nav className="flex flex-col space-y-4 mt-8">
                    <Link href="/products" className="text-lg hover:text-primary">
                      المنتجات
                    </Link>
                    <Link href="/categories" className="text-lg hover:text-primary">
                      الأقسام
                    </Link>
                    <Link href="/about" className="text-lg hover:text-primary">
                      عن المنصة
                    </Link>
                    <Link href="/contact" className="text-lg hover:text-primary">
                      اتصل بنا
                    </Link>
                    {isSeller && (
                      <Link href="/seller/dashboard" className="text-lg hover:text-primary">
                        لوحة التحكم
                      </Link>
                    )}
                  </nav>
                </SheetContent>
              </Sheet>
            )}
          </div>
        </div>
      </div>
    </header>
  )
}
